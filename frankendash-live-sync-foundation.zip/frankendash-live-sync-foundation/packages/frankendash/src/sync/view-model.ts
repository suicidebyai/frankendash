import type {
  SyncEvent,
  SyncSourceState,
  SyncStatus,
} from "../../../contracts/src/live-sync";

export interface SyncBadgeModel {
  status: SyncStatus;
  label: "LIVE" | "SYNCING" | "OFFLINE" | "STALE" | "CONFLICT" | "ERROR";
  lastSuccessAt?: string;
}

export interface SyncPanelModel {
  badge: SyncBadgeModel;
  sources: SyncSourceState[];
  activity: SyncEvent[];
}

export function aggregateSyncStatus(
  sources: SyncSourceState[],
): SyncStatus {
  if (sources.some((s) => s.status === "conflict")) return "conflict";
  if (sources.some((s) => s.status === "error")) return "error";
  if (sources.some((s) => s.status === "syncing")) return "syncing";
  if (sources.length > 0 && sources.every((s) => s.status === "offline")) {
    return "offline";
  }
  if (sources.some((s) => s.status === "stale")) return "stale";
  return "live";
}
