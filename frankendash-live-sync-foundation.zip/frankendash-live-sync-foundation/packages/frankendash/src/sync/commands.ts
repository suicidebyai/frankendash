export type SyncCommand =
  | { type: "sync.now"; sourceId: string }
  | { type: "sync.all" }
  | { type: "sync.retry"; sourceId: string }
  | { type: "sync.resolve-conflict"; conflictId: string; resolution: "local" | "remote" | "manual" };

export interface SyncCommandBus {
  dispatch(command: SyncCommand): Promise<void>;
}
