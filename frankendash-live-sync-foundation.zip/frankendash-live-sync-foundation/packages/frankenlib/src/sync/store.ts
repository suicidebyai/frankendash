import type {
  NormalizedEntity,
  SyncCursor,
  SyncSourceRef,
  SyncSourceState,
} from "../../../contracts/src/live-sync";

export type ReconcileOutcome = "unchanged" | "changed" | "conflict";

export interface SyncStore {
  getCursor(sourceId: string): Promise<SyncCursor | null>;
  setCursor(cursor: SyncCursor): Promise<void>;

  reconcile(entity: NormalizedEntity): Promise<ReconcileOutcome>;

  markAttempt(source: SyncSourceRef, at: string): Promise<SyncSourceState>;
  markSuccess(source: SyncSourceRef, at: string): Promise<SyncSourceState>;
  markOffline(source: SyncSourceRef, at: string): Promise<SyncSourceState>;
  markError(
    source: SyncSourceRef,
    at: string,
    error: string,
  ): Promise<SyncSourceState>;

  getSourceStates(): Promise<SyncSourceState[]>;
}
