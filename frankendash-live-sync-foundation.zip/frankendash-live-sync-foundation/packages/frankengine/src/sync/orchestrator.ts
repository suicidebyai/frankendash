import type {
  SyncEvent,
  SyncSourceState,
} from "../../../contracts/src/live-sync";
import type { SyncConnector } from "./connector";
import type { SyncStore } from "../../../frankenlib/src/sync/store";

export interface SyncEventSink {
  emit(event: SyncEvent): Promise<void> | void;
}

export class SyncOrchestrator {
  private readonly connectors = new Map<string, SyncConnector>();

  constructor(
    private readonly store: SyncStore,
    private readonly events: SyncEventSink,
  ) {}

  register(connector: SyncConnector): void {
    this.connectors.set(connector.source.id, connector);
  }

  async syncSource(sourceId: string): Promise<SyncSourceState> {
    const connector = this.connectors.get(sourceId);
    if (!connector) throw new Error(`Unknown sync source: ${sourceId}`);

    const at = new Date().toISOString();
    await this.events.emit({ type: "sync.started", source: connector.source, at });
    await this.store.markAttempt(connector.source, at);

    try {
      const available = await connector.isAvailable();

      if (!available) {
        const state = await this.store.markOffline(connector.source, at);
        await this.events.emit({
          type: "sync.failed",
          source: connector.source,
          at,
          error: "Source unavailable",
        });
        return state;
      }

      const cursor = await this.store.getCursor(connector.source.id);
      const result = await connector.pull(cursor);

      let changed = 0;
      for (const entity of result.entities) {
        const outcome = await this.store.reconcile(entity);
        if (outcome === "changed") {
          changed += 1;
          await this.events.emit({
            type: "entity.changed",
            source: connector.source,
            at: new Date().toISOString(),
            entity,
          });
        }
      }

      if (result.cursor) await this.store.setCursor(result.cursor);
      const state = await this.store.markSuccess(
        connector.source,
        new Date().toISOString(),
      );

      await this.events.emit({
        type: "sync.completed",
        source: connector.source,
        at: new Date().toISOString(),
        changed,
      });

      return state;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      const failedAt = new Date().toISOString();
      const state = await this.store.markError(
        connector.source,
        failedAt,
        message,
      );
      await this.events.emit({
        type: "sync.failed",
        source: connector.source,
        at: failedAt,
        error: message,
      });
      return state;
    }
  }

  async syncAll(): Promise<SyncSourceState[]> {
    const states: SyncSourceState[] = [];
    for (const sourceId of this.connectors.keys()) {
      states.push(await this.syncSource(sourceId));
    }
    return states;
  }
}
