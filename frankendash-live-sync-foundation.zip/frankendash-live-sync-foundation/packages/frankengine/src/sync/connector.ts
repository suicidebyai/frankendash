import type {
  NormalizedEntity,
  SyncCursor,
  SyncSourceRef,
} from "../../../contracts/src/live-sync";

export interface PullResult {
  cursor: SyncCursor | null;
  entities: NormalizedEntity[];
}

export interface SyncConnector {
  readonly source: SyncSourceRef;

  isAvailable(): Promise<boolean>;

  pull(cursor: SyncCursor | null): Promise<PullResult>;

  /**
   * Optional provider write path.
   * Keep disabled unless the provider implementation explicitly supports it.
   */
  push?(entities: NormalizedEntity[]): Promise<void>;
}
