export type SyncStatus =
  | "live"
  | "syncing"
  | "offline"
  | "stale"
  | "conflict"
  | "error";

export type SyncSourceKind =
  | "github"
  | "google-drive"
  | "notion"
  | "airtable"
  | "tasks"
  | "plugin"
  | "custom";

export interface SyncSourceRef {
  id: string;
  kind: SyncSourceKind;
  label: string;
}

export interface SyncCursor {
  sourceId: string;
  value: string | null;
  updatedAt: string;
}

export interface NormalizedEntity {
  id: string;
  entityType: "project" | "task" | "document" | "file" | "activity" | "knowledge" | "custom";
  title?: string;
  source: SyncSourceRef;
  sourceEntityId: string;
  revision?: string;
  updatedAt: string;
  data: Record<string, unknown>;
}

export interface SyncConflict {
  id: string;
  source: SyncSourceRef;
  entityId: string;
  detectedAt: string;
  localRevision?: string;
  remoteRevision?: string;
  localValue: Record<string, unknown>;
  remoteValue: Record<string, unknown>;
}

export interface SyncSourceState {
  source: SyncSourceRef;
  status: SyncStatus;
  lastAttemptAt?: string;
  lastSuccessAt?: string;
  lastError?: string;
  cursor?: SyncCursor;
  pendingConflicts: number;
}

export type SyncEvent =
  | { type: "sync.started"; source: SyncSourceRef; at: string }
  | { type: "sync.progress"; source: SyncSourceRef; at: string; message?: string }
  | { type: "sync.completed"; source: SyncSourceRef; at: string; changed: number }
  | { type: "sync.failed"; source: SyncSourceRef; at: string; error: string }
  | { type: "sync.conflict"; source: SyncSourceRef; at: string; conflict: SyncConflict }
  | { type: "entity.changed"; source: SyncSourceRef; at: string; entity: NormalizedEntity };
