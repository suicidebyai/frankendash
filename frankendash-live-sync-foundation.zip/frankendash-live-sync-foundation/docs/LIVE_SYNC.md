# Live Sync Architecture

## Goal

Make Frankendash reflect current workspace state without coupling the UI to GitHub, Drive, Notion, Airtable, task providers, or future integrations.

## Canonical flow

```text
GitHub / Drive / Notion / Airtable / Tasks / Plugins
                        |
                        v
                Connector Adapters
                        |
                        v
                  FrankEngine
               Sync Orchestrator
                        |
             normalize + reconcile
                        |
                        v
                   Frankenlib
           persistence / index / cache
                        |
                        v
                  FrankEngine
                 event projection
                        |
                        v
                  Frankendash
```

## Ownership

### Frankendash
Owns rendering and user interaction:
- sync badge
- sync activity stream
- source status
- manual refresh
- retry
- conflict-resolution UI
- project/task/file/workbench projections

### FrankEngine
Owns:
- connector orchestration
- scheduling
- normalization
- reconciliation policy
- conflict detection
- command handling
- emitting domain/sync events

### Frankenlib
FrankEngine module responsible for:
- canonical local records
- sync cursors
- source metadata
- cache
- indexes
- event history
- conflict snapshots
- last-known-good state

## Rule

No Frankendash component imports provider SDKs or provider-shaped objects.

Provider data must be normalized before crossing the FrankEngine → Frankendash boundary.
