# Live Sync Foundation Completion Criteria

Foundation is complete when:

1. A provider-neutral connector can be registered with FrankEngine.
2. FrankEngine can request a sync and receive normalized changes.
3. Frankenlib can persist sync source status, cursors, normalized entities, and conflicts.
4. FrankEngine can emit UI-safe sync events.
5. Frankendash can represent `live`, `syncing`, `offline`, `stale`, `conflict`, and `error`.
6. Manual `sync now` can target one source or all enabled sources.
7. A provider outage cannot corrupt last-known-good local state.
8. No provider SDK or raw credential crosses into Frankendash.
9. Conflict state is explicit rather than silently choosing a winner.
10. The architecture remains usable offline with cached/local state.
