# Frankendash Live Sync Foundation

Implementation-ready scaffold for Frankendash ↔ FrankEngine ↔ Frankenlib live synchronization.

## Boundary

External Sources → Connector Adapters → FrankEngine Sync Orchestrator → Frankenlib Sync Store → FrankEngine Events → Frankendash UI

Frankendash never talks directly to provider APIs. FrankEngine owns orchestration. Frankenlib owns persisted/indexed sync state.

## Status model

- `live`
- `syncing`
- `offline`
- `stale`
- `conflict`
- `error`

## Included

- shared sync contracts
- connector adapter interface
- FrankEngine sync orchestrator skeleton
- Frankenlib persistence interface
- UI event/view model
- architecture notes and completion criteria

This scaffold is intentionally provider-agnostic and local-first.
